const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const config = require('../config.json');
const { get, run } = require('../database/db');
const logger = require('../utils/logger');
const { buildCitizenCard } = require('../utils/embedHelpers');
const { requireRole } = require('../utils/permissions');

const normalizeInput = (value, expectedLength) => {
  const result = String(value ?? '')
    .split('|')
    .map((item) => item.trim());

  while (result.length < expectedLength) result.push('');
  return result;
};

const generateVirtualCedula = (userId) => `CED-${Date.now().toString().slice(-8)}-${String(userId).slice(-4)}`;

const logEvent = (eventType, userId, moderator, details) => {
  run(
    'INSERT INTO logs (event_type, user_id, moderator, details, created_at) VALUES (?, ?, ?, ?, ?)',
    [eventType, userId, moderator, details, new Date().toISOString()]
  );
};

const findMinsegChannel = async (guild) => {
  const configuredName = String(config.channels?.minseg || '').trim().toLowerCase();

  const cachedChannel = guild?.channels?.cache?.find((channel) => {
    return channel?.isTextBased?.() && channel?.name?.toLowerCase?.() === configuredName;
  });

  if (cachedChannel) return cachedChannel;

  const fetchedChannels = await guild?.channels?.fetch?.().catch(() => null);
  return fetchedChannels?.find((channel) => {
    return channel?.isTextBased?.() && channel?.name?.toLowerCase?.() === configuredName;
  });
};

const notifyMinsegWebhook = async (interaction, citizen, permitNumber, weaponType, motive, profession, residenceTime, hasCriminalRecord, phone) => {
  const webhookUrl = config.webhooks?.minseg;
  const roleId = config.roleIds?.minseg;

  if (!webhookUrl) return;

  const richEmbed = new EmbedBuilder()
    .setColor(config.colors.warning)
    .setTitle('🔫 Solicitud de permiso de armas')
    .setDescription(`Nueva solicitud para revisión de MINSEG. La petición está pendiente de aprobación.`)
    .setAuthor({
      name: `${interaction.user.tag} • ${citizen.full_name}`,
      iconURL: interaction.user.displayAvatarURL({ dynamic: true })
    })
    .addFields(
      { name: '📌 Número de solicitud', value: permitNumber, inline: true },
      { name: '🧾 Cédula', value: citizen.cedula, inline: true },
      { name: '🎯 Tipo de arma', value: weaponType, inline: true },
      { name: '💼 Profesión', value: profession, inline: true },
      { name: '⏳ Tiempo de residencia', value: residenceTime, inline: true },
      { name: '📞 Teléfono', value: phone || 'No indicado', inline: true },
      { name: '🚨 Antecedentes', value: hasCriminalRecord || 'No indicado', inline: false },
      { name: '📝 Motivo', value: motive || 'No especificado', inline: false }
    )
    .setTimestamp(new Date())
    .setFooter({
      text: 'Sistema CAD/MDT • MINSEG',
      iconURL: interaction.guild.iconURL({ dynamic: true }) || undefined
    });

  const payload = {
    content: roleId ? `<@&${roleId}> Nueva solicitud de permiso de armas (${permitNumber}) lista para revisión.` : `Nueva solicitud de permiso de armas (${permitNumber}) lista para revisión.`,
    allowed_mentions: roleId ? { roles: [roleId] } : undefined,
    username: 'MINSEG Bot',
    avatar_url: interaction.guild.iconURL({ dynamic: true }) || undefined,
    embeds: [richEmbed.toJSON()]
  };

  await fetch(webhookUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });
};

module.exports = (client) => {
  client.on('interactionCreate', async (interaction) => {
    try {
      if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;
        await command.execute(interaction, client);
        return;
      }

      if (interaction.isModalSubmit()) {
        if (interaction.customId === 'registro_civil_modal') {
          const fullName = interaction.fields.getTextInputValue('full_name');
          const cedula = generateVirtualCedula(interaction.user.id);
          const [birthDate, ageText] = normalizeInput(interaction.fields.getTextInputValue('birth_date'), 2);
          const age = Number(ageText || 0);
          const sex = interaction.fields.getTextInputValue('sex');
          const [province = '', district = '', corregimiento = '', address = '', nationality = ''] = normalizeInput(
            interaction.fields.getTextInputValue('extra_details'),
            5
          );

          const existing = get('SELECT id FROM citizens WHERE discord_id = ?', [interaction.user.id]);
          if (existing) {
            await interaction.reply({ content: 'Ya existe un registro con ese Discord ID.', flags: 64 });
            return;
          }

          const internalId = `PAN-${Date.now().toString().slice(-6)}`;
          const createdAt = new Date().toISOString();

          run(
            `INSERT INTO citizens (internal_id, discord_id, full_name, cedula, birth_date, age, sex, province, district, corregimiento, address, nationality, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [internalId, interaction.user.id, fullName, cedula, birthDate, age, sex, province, district, corregimiento, address, nationality, createdAt, createdAt]
          );

          run(
            `INSERT INTO history (citizen_id, event_type, actor, moderator, details, created_at)
             VALUES ((SELECT id FROM citizens WHERE discord_id = ?), 'REGISTRO_CIVIL', ?, 'SYSTEM', 'Registro civil completado', ?)`,
            [interaction.user.id, interaction.user.tag, createdAt]
          );

          logEvent('REGISTRO_CIVIL', interaction.user.id, 'SYSTEM', `Ciudadano registrado con ${internalId}`);

          const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
          const embed = buildCitizenCard(citizen);
          await interaction.reply({ embeds: [embed] });
          logger.info(`Ciudadano registrado: ${interaction.user.tag} (${internalId})`);
        }

        if (interaction.customId === 'actualizar_datos_modal') {
          const fullName = interaction.fields.getTextInputValue('full_name');
          const [province = '', district = '', corregimiento = '', address = ''] = normalizeInput(
            interaction.fields.getTextInputValue('extra_details'),
            4
          );

          run(
            `UPDATE citizens SET full_name = ?, province = ?, district = ?, corregimiento = ?, address = ?, updated_at = ? WHERE discord_id = ?`,
            [fullName, province, district, corregimiento, address, new Date().toISOString(), interaction.user.id]
          );

          logEvent('ACTUALIZACION_DATOS', interaction.user.id, interaction.user.tag, 'Se actualizaron datos del ciudadano.');
          await interaction.reply({ content: 'Datos actualizados correctamente.', flags: 64 });
        }

        if (interaction.customId === 'permiso_armas_modal') {
          const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
          if (!citizen) {
            await interaction.reply({ content: config.messages.mustRegister, flags: 64 });
            return;
          }

          const weaponType = interaction.fields.getTextInputValue('weapon_type');
          const motive = interaction.fields.getTextInputValue('motive');
          const profession = interaction.fields.getTextInputValue('profession');
          const residenceTime = interaction.fields.getTextInputValue('residence_time');
          const [hasCriminalRecord = '', phone = ''] = normalizeInput(interaction.fields.getTextInputValue('extra_details'), 2);
          const permitNumber = `AR-${Date.now().toString().slice(-8)}`;
          const createdAt = new Date().toISOString();

          run(
            `INSERT INTO permissions (citizen_id, permit_number, weapon_type, motive, profession, residence_time, has_criminal_record, phone, status, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PENDIENTE', ?)`,
            [citizen.id, permitNumber, weaponType, motive, profession, residenceTime, hasCriminalRecord, phone, createdAt]
          );

          const minsegChannel = await findMinsegChannel(interaction.guild);
          const approveButton = new ButtonBuilder().setCustomId(`approve_weapon_${permitNumber}`).setLabel('✅ Aprobar').setStyle(ButtonStyle.Success);
          const rejectButton = new ButtonBuilder().setCustomId(`reject_weapon_${permitNumber}`).setLabel('❌ Rechazar').setStyle(ButtonStyle.Danger);
          const row = new ActionRowBuilder().addComponents(approveButton, rejectButton);

          const embed = new EmbedBuilder()
            .setColor(config.colors.warning)
            .setTitle('Solicitud de permiso de armas')
            .addFields(
              { name: 'Cédula', value: citizen.cedula, inline: true },
              { name: 'Tipo de arma', value: weaponType, inline: true },
              { name: 'Motivo', value: motive, inline: false },
              { name: 'Profesión', value: profession, inline: true },
              { name: 'Tiempo de residencia', value: residenceTime, inline: true },
              { name: 'Antecedentes', value: hasCriminalRecord, inline: true },
              { name: 'Teléfono', value: phone, inline: true }
            );

          if (minsegChannel) {
            await minsegChannel.send({ embeds: [embed], components: [row] });
          }

          try {
            await notifyMinsegWebhook(interaction, citizen, permitNumber, weaponType, motive, profession, residenceTime, hasCriminalRecord, phone);
          } catch (webhookError) {
            logger.error('Error al enviar webhook de MINSEG.', webhookError);
          }

          logEvent('SOLICITUD_PERMISO_ARMAS', interaction.user.id, interaction.user.tag, `Solicitud ${permitNumber} enviada al MINSEG.`);
          await interaction.reply({ content: 'Tu solicitud fue enviada al MINSEG para revisión.', flags: 64 });
        }

        if (interaction.customId.startsWith('reject_weapon_modal__')) {
          const permitNumber = interaction.customId.replace('reject_weapon_modal__', '');
          const reason = interaction.fields.getTextInputValue('reject_reason');
          const permission = get('SELECT * FROM permissions WHERE permit_number = ?', [permitNumber]);
          const citizen = get('SELECT * FROM citizens WHERE id = ?', [permission.citizen_id]);

          run('UPDATE permissions SET status = ?, rejection_reason = ?, officer = ? WHERE permit_number = ?', ['RECHAZADO', reason, interaction.user.tag, permitNumber]);
          logEvent('RECHAZO_PERMISO_ARMAS', interaction.user.id, interaction.user.tag, `Permiso ${permitNumber} rechazado: ${reason}`);

          if (citizen) {
            const user = await client.users.fetch(citizen.discord_id).catch(() => null);
            if (user) await user.send(`Tu solicitud de permiso de armas fue rechazada. Motivo: ${reason}`);
          }

          await interaction.reply({ content: 'Permiso rechazado y ciudadano notificado.', flags: 64 });
        }

        if (interaction.customId === 'revocar_permiso_modal') {
          const reason = interaction.fields.getTextInputValue('revoke_reason');
          const permission = get('SELECT * FROM permissions WHERE citizen_id = (SELECT id FROM citizens WHERE discord_id = ?) ORDER BY id DESC LIMIT 1', [interaction.user.id]);
          if (!permission) {
            await interaction.reply({ content: 'No existe permiso registrado para este ciudadano.', flags: 64 });
            return;
          }

          run('UPDATE permissions SET status = ?, revoked_reason = ?, officer = ? WHERE id = ?', ['REVOKADO', reason, interaction.user.tag, permission.id]);
          logEvent('REVOCACION_PERMISO_ARMAS', interaction.user.id, interaction.user.tag, `Revocación por motivo: ${reason}`);
          await interaction.reply({ content: 'Permiso revocado correctamente.', flags: 64 });
        }

        if (interaction.customId === 'licencia_modal') {
          const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
          if (!citizen) {
            await interaction.reply({ content: config.messages.mustRegister, flags: 64 });
            return;
          }

          const licenseType = interaction.fields.getTextInputValue('license_type');
          const reason = interaction.fields.getTextInputValue('license_reason');
          const number = `LIC-${Date.now().toString().slice(-8)}`;
          run('INSERT INTO licenses (citizen_id, type, status, number, issued_by, issued_at) VALUES (?, ?, ?, ?, ?, ?)', [citizen.id, licenseType, 'PENDIENTE', number, interaction.user.tag, new Date().toISOString()]);
          await interaction.reply({ content: `Solicitud de licencia registrada con número ${number}.`, flags: 64 });
        }

        if (interaction.customId === 'empresa_modal') {
          const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
          if (!citizen) {
            await interaction.reply({ content: config.messages.mustRegister, flags: 64 });
            return;
          }

          const name = interaction.fields.getTextInputValue('company_name');
          const ruc = interaction.fields.getTextInputValue('company_ruc');
          run('INSERT INTO companies (name, owner_id, ruc, created_at) VALUES (?, ?, ?, ?)', [name, citizen.id, ruc, new Date().toISOString()]);
          await interaction.reply({ content: `Empresa registrada correctamente: ${name}`, flags: 64 });
        }

        return;
      }

      if (interaction.isButton()) {
        if (interaction.customId.startsWith('approve_weapon_')) {
          if (!requireRole(interaction, 'minseg')) return;
          const permitNumber = interaction.customId.replace('approve_weapon_', '');
          const permit = get('SELECT * FROM permissions WHERE permit_number = ?', [permitNumber]);
          if (!permit) {
            await interaction.reply({ content: 'No existe esa solicitud.', flags: 64 });
            return;
          }

          run('UPDATE permissions SET status = ?, officer = ?, approved_at = ? WHERE permit_number = ?', ['APROBADO', interaction.user.tag, new Date().toISOString(), permitNumber]);
          const citizen = get('SELECT * FROM citizens WHERE id = ?', [permit.citizen_id]);
          const user = citizen ? await client.users.fetch(citizen.discord_id).catch(() => null) : null;
          if (user) await user.send('Tu permiso de armas ha sido aprobado.');

          logEvent('APROBACION_PERMISO_ARMAS', interaction.user.id, interaction.user.tag, `Permiso ${permitNumber} aprobado.`);
          await interaction.reply({ content: 'Permiso aprobado con éxito.', flags: 64 });
          return;
        }

        if (interaction.customId.startsWith('reject_weapon_')) {
          if (!requireRole(interaction, 'minseg')) return;
          const permitNumber = interaction.customId.replace('reject_weapon_', '');
          const modal = new ModalBuilder()
            .setCustomId(`reject_weapon_modal__${permitNumber}`)
            .setTitle('Motivo de rechazo');

          const reason = new TextInputBuilder()
            .setCustomId('reject_reason')
            .setLabel('Motivo del rechazo')
            .setRequired(true)
            .setStyle(TextInputStyle.Paragraph);

          modal.addComponents(new ActionRowBuilder().addComponents(reason));
          await interaction.showModal(modal);
          return;
        }
      }
    } catch (error) {
      logger.error('Error en interactionCreate.', error);
      const isCommandInteraction = interaction.isChatInputCommand();
      if (!isCommandInteraction && !interaction.replied && !interaction.deferred && interaction.isRepliable()) {
        await interaction.reply({ content: config.messages.commandError, flags: 64 }).catch(() => undefined);
      }
    }
  });
};
