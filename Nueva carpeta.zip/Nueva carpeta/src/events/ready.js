const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config.json');
const logger = require('../utils/logger');

module.exports = (client) => {
  client.once('ready', async () => {
    logger.info(`Bot listo como ${client.user.tag}`);

    if (!config.token || !config.clientId) {
      logger.warn('Faltan datos de token/clientId en config.json');
      return;
    }

    const commands = [];
    const commandsDir = path.join(__dirname, '..', 'commands');

    for (const file of fs.readdirSync(commandsDir).filter((f) => f.endsWith('.js'))) {
      const command = require(path.join(commandsDir, file));
      if (command?.data?.name) commands.push(command.data.toJSON());
    }

    const rest = new REST({ version: '10' }).setToken(config.token);

    try {
      if (config.guildId && !config.guildId.startsWith('REEMPLAZA')) {
        await rest.put(Routes.applicationCommands(config.clientId), {
          body: []
        });
        await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), {
          body: commands
        });
        logger.info('Comandos de barra registrados en el servidor guild.');
      } else {
        await rest.put(Routes.applicationCommands(config.clientId), {
          body: commands
        });
        logger.info('Comandos de barra registrados a nivel global.');
      }
    } catch (error) {
      logger.error('No se pudieron registrar los comandos.', error);
    }
  });
};
