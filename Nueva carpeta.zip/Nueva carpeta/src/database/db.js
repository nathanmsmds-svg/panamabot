const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const defaultConfig = require('../config.json');
const config = {
  ...defaultConfig,
  database: {
    ...defaultConfig.database,
    path: process.env.DB_PATH || defaultConfig.database.path
  }
};
const logger = require('../utils/logger');

const dbPath = path.resolve(process.cwd(), config.database.path.replace('./', ''));
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new DatabaseSync(dbPath);

db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA busy_timeout = 3000;');

const schema = `
CREATE TABLE IF NOT EXISTS citizens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  internal_id TEXT UNIQUE NOT NULL,
  discord_id TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  cedula TEXT UNIQUE NOT NULL,
  birth_date TEXT NOT NULL,
  age INTEGER NOT NULL,
  sex TEXT NOT NULL,
  province TEXT NOT NULL,
  district TEXT NOT NULL,
  corregimiento TEXT NOT NULL,
  address TEXT NOT NULL,
  nationality TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS permissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  citizen_id INTEGER NOT NULL,
  permit_number TEXT UNIQUE NOT NULL,
  weapon_type TEXT NOT NULL,
  motive TEXT NOT NULL,
  profession TEXT NOT NULL,
  residence_time TEXT NOT NULL,
  has_criminal_record TEXT NOT NULL,
  phone TEXT NOT NULL,
  status TEXT DEFAULT 'PENDIENTE',
  officer TEXT,
  approved_at TEXT,
  rejection_reason TEXT,
  revoked_reason TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(citizen_id) REFERENCES citizens(id)
);

CREATE TABLE IF NOT EXISTS fines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  citizen_id INTEGER NOT NULL,
  officer TEXT NOT NULL,
  amount REAL NOT NULL,
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(citizen_id) REFERENCES citizens(id)
);

CREATE TABLE IF NOT EXISTS arrests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  citizen_id INTEGER NOT NULL,
  officer TEXT NOT NULL,
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(citizen_id) REFERENCES citizens(id)
);

CREATE TABLE IF NOT EXISTS licenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  citizen_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  status TEXT DEFAULT 'PENDIENTE',
  number TEXT UNIQUE NOT NULL,
  issued_by TEXT,
  issued_at TEXT,
  FOREIGN KEY(citizen_id) REFERENCES citizens(id)
);

CREATE TABLE IF NOT EXISTS companies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  owner_id INTEGER NOT NULL,
  ruc TEXT UNIQUE NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(owner_id) REFERENCES citizens(id)
);

CREATE TABLE IF NOT EXISTS history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  citizen_id INTEGER,
  event_type TEXT NOT NULL,
  actor TEXT NOT NULL,
  moderator TEXT,
  details TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_type TEXT NOT NULL,
  user_id TEXT,
  moderator TEXT,
  details TEXT NOT NULL,
  created_at TEXT NOT NULL
);
`;

const initDatabase = () => {
  try {
    db.exec(schema);
    logger.info(`Base de datos inicializada: ${dbPath}`);
  } catch (error) {
    logger.error('No se pudo inicializar SQLite.', error);
    throw error;
  }
};

const normalizeParams = (params = []) => (Array.isArray(params) ? params : [params]);
const run = (sql, params = []) => db.prepare(sql).run(...normalizeParams(params));
const get = (sql, params = []) => db.prepare(sql).get(...normalizeParams(params));
const all = (sql, params = []) => db.prepare(sql).all(...normalizeParams(params));

module.exports = {
  db,
  initDatabase,
  run,
  get,
  all
};
