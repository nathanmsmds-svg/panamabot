const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { get } = require('../database/db');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('licencia')
    .setDescription('Consulta las licencias asociadas al ciudadano.'),

  async execute(interaction) {
    const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
    if (!citizen) {
      await interaction.reply({ content: config.messages.mustRegister, flags: 64 });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(config.colors.success)
      .setTitle('Licencias')
      .setDescription('No tienes licencias registradas aún.');

    await interaction.reply({ embeds: [embed] });
  }
};
