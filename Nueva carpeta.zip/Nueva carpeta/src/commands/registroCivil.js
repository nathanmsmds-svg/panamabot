const { SlashCommandBuilder, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('registro-civil')
    .setDescription('Registra al ciudadano en el Registro Civil de Panamá.'),

  async execute(interaction) {
    const modal = new ModalBuilder()
      .setCustomId('registro_civil_modal')
      .setTitle('Registro Civil - República de Panamá');

    const fullName = new TextInputBuilder()
      .setCustomId('full_name')
      .setLabel('Nombre completo')
      .setRequired(true)
      .setStyle(TextInputStyle.Short);

    const birthDate = new TextInputBuilder()
      .setCustomId('birth_date')
      .setLabel('Fecha de nacimiento | Edad')
      .setRequired(true)
      .setStyle(TextInputStyle.Short);

    const sex = new TextInputBuilder()
      .setCustomId('sex')
      .setLabel('Sexo')
      .setRequired(true)
      .setStyle(TextInputStyle.Short);

    const details = new TextInputBuilder()
      .setCustomId('extra_details')
      .setLabel('Ubicación y nacionalidad')
      .setRequired(true)
      .setStyle(TextInputStyle.Paragraph);

    modal.addComponents(
      new ActionRowBuilder().addComponents(fullName),
      new ActionRowBuilder().addComponents(birthDate),
      new ActionRowBuilder().addComponents(sex),
      new ActionRowBuilder().addComponents(details)
    );

    await interaction.showModal(modal);
  }
};
