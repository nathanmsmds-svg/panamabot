const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { get } = require('../database/db');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('antecedentes')
    .setDescription('Consulta los antecedentes de un ciudadano.'),

  async execute(interaction) {
    const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
    if (!citizen) {
      await interaction.reply({ content: config.messages.mustRegister, flags: 64 });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(config.colors.warning)
      .setTitle('Antecedentes')
      .setDescription('Sin antecedentes reportados.');

    await interaction.reply({ embeds: [embed] });
  }
};
