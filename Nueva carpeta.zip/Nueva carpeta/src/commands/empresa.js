const { SlashCommandBuilder, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('empresa')
    .setDescription('Registra una empresa en el sistema gubernamental.'),

  async execute(interaction) {
    const modal = new ModalBuilder()
      .setCustomId('empresa_modal')
      .setTitle('Registro de empresa');

    const name = new TextInputBuilder().setCustomId('company_name').setLabel('Nombre de la empresa').setRequired(true).setStyle(TextInputStyle.Short);
    const ruc = new TextInputBuilder().setCustomId('company_ruc').setLabel('RUC').setRequired(true).setStyle(TextInputStyle.Short);

    modal.addComponents(
      new ActionRowBuilder().addComponents(name),
      new ActionRowBuilder().addComponents(ruc)
    );

    await interaction.showModal(modal);
  }
};
