const { SlashCommandBuilder, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('actualizar-datos')
    .setDescription('Actualiza los datos del ciudadano en el Registro Civil.'),

  async execute(interaction) {
    const modal = new ModalBuilder()
      .setCustomId('actualizar_datos_modal')
      .setTitle('Actualizar datos ciudadanos');

    const fullName = new TextInputBuilder()
      .setCustomId('full_name')
      .setLabel('Nombre completo')
      .setRequired(true)
      .setStyle(TextInputStyle.Short);

    const details = new TextInputBuilder()
      .setCustomId('extra_details')
      .setLabel('Datos de ubicación')
      .setRequired(true)
      .setStyle(TextInputStyle.Paragraph);

    modal.addComponents(
      new ActionRowBuilder().addComponents(fullName),
      new ActionRowBuilder().addComponents(details)
    );

    await interaction.showModal(modal);
  }
};
