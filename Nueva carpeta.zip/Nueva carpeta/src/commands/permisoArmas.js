const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { get } = require('../database/db');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('permiso-armas')
    .setDescription('Consulta el estado del permiso de armas del ciudadano.'),

  async execute(interaction) {
    const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
    if (!citizen) {
      await interaction.reply({ content: config.messages.mustRegister, flags: 64 });
      return;
    }

    const permit = get('SELECT * FROM permissions WHERE citizen_id = ? ORDER BY id DESC LIMIT 1', [citizen.id]);
    if (!permit) {
      await interaction.reply({ content: 'Aún no tienes un permiso de armas registrado.', flags: 64 });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle('Permiso de armas')
      .addFields(
        { name: 'Estado', value: permit.status, inline: true },
        { name: 'Funcionario', value: permit.officer || 'Pendiente', inline: true },
        { name: 'Fecha', value: permit.approved_at || permit.created_at, inline: true },
        { name: 'Número de permiso', value: permit.permit_number, inline: true },
        { name: 'Tipo de arma', value: permit.weapon_type, inline: true }
      );

    await interaction.reply({ embeds: [embed] });
  }
};
