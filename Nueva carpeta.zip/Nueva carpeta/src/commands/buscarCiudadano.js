const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { get, all } = require('../database/db');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('buscar-ciudadano')
    .setDescription('Busca un ciudadano por nombre, Discord ID o cédula.'),

  async execute(interaction) {
    const citizen = get('SELECT * FROM citizens WHERE discord_id = ? LIMIT 1', [interaction.user.id]);
    if (!citizen) {
      await interaction.reply({ content: config.messages.mustRegister, flags: 64 });
      return;
    }

    const fines = all('SELECT * FROM fines WHERE citizen_id = ?', [citizen.id]);
    const arrests = all('SELECT * FROM arrests WHERE citizen_id = ?', [citizen.id]);
    const permits = all('SELECT * FROM permissions WHERE citizen_id = ?', [citizen.id]);

    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle('Búsqueda de ciudadano')
      .addFields(
        { name: 'Nombre', value: citizen.full_name, inline: true },
        { name: 'Cédula', value: citizen.cedula, inline: true },
        { name: 'Discord', value: `<@${citizen.discord_id}>`, inline: true },
        { name: 'Multas', value: String(fines.length), inline: true },
        { name: 'Arrestos', value: String(arrests.length), inline: true },
        { name: 'Permisos', value: String(permits.length), inline: true }
      );

    await interaction.reply({ embeds: [embed] });
  }
};
