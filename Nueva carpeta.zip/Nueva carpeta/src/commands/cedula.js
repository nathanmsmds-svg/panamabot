const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { get } = require('../database/db');
const { buildCitizenCard } = require('../utils/embedHelpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cedula')
    .setDescription('Muestra la cédula virtual del ciudadano registrado.'),

  async execute(interaction) {
    const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
    if (!citizen) {
      await interaction.reply({ content: 'Primero debes registrarte en el Registro Civil usando /registro-civil.', flags: 64 });
      return;
    }

    const embed = buildCitizenCard(citizen);
    await interaction.reply({ embeds: [embed] });
  }
};
