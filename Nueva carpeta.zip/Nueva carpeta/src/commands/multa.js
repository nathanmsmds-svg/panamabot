const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { requireRole } = require('../utils/permissions');
const { run, get } = require('../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('multa')
    .setDescription('Registra una multa a un ciudadano. Solo Policía Nacional.'),

  async execute(interaction) {
    if (!requireRole(interaction, 'policia')) return;

    const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
    if (!citizen) {
      await interaction.reply({ content: 'Primero debes registrarte en el Registro Civil usando /registro-civil.', flags: 64 });
      return;
    }

    const amount = 100;
    const reason = 'Infracción registrada en MDT';
    const createdAt = new Date().toISOString();
    run('INSERT INTO fines (citizen_id, officer, amount, reason, created_at) VALUES (?, ?, ?, ?, ?)', [citizen.id, interaction.user.tag, amount, reason, createdAt]);

    const embed = new EmbedBuilder()
      .setColor(0xf1c40f)
      .setTitle('Multa registrada')
      .addFields(
        { name: 'Ciudadano', value: citizen.full_name, inline: true },
        { name: 'Monto', value: `${amount}`, inline: true },
        { name: 'Motivo', value: reason, inline: true }
      );

    await interaction.reply({ embeds: [embed] });
  }
};
