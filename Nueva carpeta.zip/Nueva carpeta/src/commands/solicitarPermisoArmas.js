const { SlashCommandBuilder, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { get } = require('../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('solicitar-permiso-armas')
    .setDescription('Solicita un permiso de armas.'),

  async execute(interaction) {
    const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
    if (!citizen) {
      await interaction.reply({ content: 'Primero debes registrarte en el Registro Civil usando /registro-civil.', flags: 64 });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId('permiso_armas_modal')
      .setTitle('Solicitud de permiso de armas');

    const weaponType = new TextInputBuilder().setCustomId('weapon_type').setLabel('Tipo de arma').setRequired(true).setStyle(TextInputStyle.Short);
    const motive = new TextInputBuilder().setCustomId('motive').setLabel('Motivo').setRequired(true).setStyle(TextInputStyle.Paragraph);
    const profession = new TextInputBuilder().setCustomId('profession').setLabel('Profesión').setRequired(true).setStyle(TextInputStyle.Short);
    const residenceTime = new TextInputBuilder().setCustomId('residence_time').setLabel('Tiempo de residencia').setRequired(true).setStyle(TextInputStyle.Short);
    const extraData = new TextInputBuilder().setCustomId('extra_details').setLabel('Antecedentes | Número telefónico').setRequired(true).setStyle(TextInputStyle.Paragraph);

    modal.addComponents(
      new ActionRowBuilder().addComponents(weaponType),
      new ActionRowBuilder().addComponents(motive),
      new ActionRowBuilder().addComponents(profession),
      new ActionRowBuilder().addComponents(residenceTime),
      new ActionRowBuilder().addComponents(extraData)
    );

    await interaction.showModal(modal);
  }
};
