const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { requireRole } = require('../utils/permissions');
const { run, get } = require('../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('arresto')
    .setDescription('Registra un arresto. Solo Policía Nacional.'),

  async execute(interaction) {
    if (!requireRole(interaction, 'policia')) return;

    const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
    if (!citizen) {
      await interaction.reply({ content: 'Primero debes registrarte en el Registro Civil usando /registro-civil.', flags: 64 });
      return;
    }

    const createdAt = new Date().toISOString();
    run('INSERT INTO arrests (citizen_id, officer, reason, created_at) VALUES (?, ?, ?, ?)', [citizen.id, interaction.user.tag, 'Arresto registrado desde MDT', createdAt]);

    const embed = new EmbedBuilder()
      .setColor(0xff4d4f)
      .setTitle('Arresto registrado')
      .addFields(
        { name: 'Ciudadano', value: citizen.full_name, inline: true },
        { name: 'Motivo', value: 'Arresto registrado desde MDT', inline: true }
      );

    await interaction.reply({ embeds: [embed] });
  }
};
