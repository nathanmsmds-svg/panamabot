const { SlashCommandBuilder } = require('discord.js');
const { get, run } = require('../database/db');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('eliminar-registro-civil')
    .setDescription('Elimina el registro civil de un ciudadano. Solo autorizado.')
    .addUserOption((option) =>
      option.setName('ciudadano').setDescription('Usuario cuyo registro civil será eliminado').setRequired(true)
    )
    .addStringOption((option) =>
      option.setName('motivo').setDescription('Motivo de la eliminación').setRequired(false)
    ),

  async execute(interaction) {
    const targetUser = interaction.options.getUser('ciudadano', true);
    const reason = interaction.options.getString('motivo') || 'Sin motivo especificado';
    const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [targetUser.id]);

    if (!citizen) {
      await interaction.reply({ content: 'Ese usuario no tiene un registro civil asociado.', flags: 64 });
      return;
    }

    run('DELETE FROM companies WHERE owner_id = ?', [citizen.id]);
    run('DELETE FROM permissions WHERE citizen_id = ?', [citizen.id]);
    run('DELETE FROM licenses WHERE citizen_id = ?', [citizen.id]);
    run('DELETE FROM fines WHERE citizen_id = ?', [citizen.id]);
    run('DELETE FROM arrests WHERE citizen_id = ?', [citizen.id]);
    run('DELETE FROM history WHERE citizen_id = ?', [citizen.id]);
    run('DELETE FROM citizens WHERE id = ?', [citizen.id]);

    run(
      'INSERT INTO logs (event_type, user_id, moderator, details, created_at) VALUES (?, ?, ?, ?, ?)',
      ['ELIMINACION_REGISTRO_CIVIL', targetUser.id, interaction.user.tag, `Registro civil eliminado por motivo: ${reason}`, new Date().toISOString()]
    );

    await interaction.reply({
      content: `Registro civil eliminado correctamente para ${targetUser.tag}. Motivo: ${reason}`,
      flags: 64
    });
  }
};
