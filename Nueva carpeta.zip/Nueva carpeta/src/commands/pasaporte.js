const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { get } = require('../database/db');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pasaporte')
    .setDescription('Emite o consulta un pasaporte.'),

  async execute(interaction) {
    const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
    if (!citizen) {
      await interaction.reply({ content: config.messages.mustRegister, flags: 64 });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(config.colors.gov)
      .setTitle('Pasaporte emitido')
      .setDescription(`Pasaporte emitido para ${citizen.full_name}.`);

    await interaction.reply({ embeds: [embed] });
  }
};
