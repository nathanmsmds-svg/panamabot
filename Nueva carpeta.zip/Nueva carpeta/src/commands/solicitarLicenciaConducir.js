const { SlashCommandBuilder, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { get } = require('../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('solicitar-licencia-conducir')
    .setDescription('Solicita una licencia de conducir.'),

  async execute(interaction) {
    const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
    if (!citizen) {
      await interaction.reply({ content: 'Primero debes registrarte en el Registro Civil usando /registro-civil.', flags: 64 });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId('licencia_modal')
      .setTitle('Solicitud de licencia de conducir');

    const category = new TextInputBuilder().setCustomId('license_type').setLabel('Tipo de licencia').setRequired(true).setStyle(TextInputStyle.Short);
    const reason = new TextInputBuilder().setCustomId('license_reason').setLabel('Motivo').setRequired(true).setStyle(TextInputStyle.Short);

    modal.addComponents(
      new ActionRowBuilder().addComponents(category),
      new ActionRowBuilder().addComponents(reason)
    );

    await interaction.showModal(modal);
  }
};
