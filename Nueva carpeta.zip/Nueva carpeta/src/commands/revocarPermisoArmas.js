const { SlashCommandBuilder, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { requireRole } = require('../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('revocar-permiso-armas')
    .setDescription('Revoca un permiso de armas. Solo MINSEG.'),

  async execute(interaction) {
    if (!requireRole(interaction, 'minseg')) return;

    const modal = new ModalBuilder()
      .setCustomId('revocar_permiso_modal')
      .setTitle('Revocación de permiso');

    const motivo = new TextInputBuilder()
      .setCustomId('revoke_reason')
      .setLabel('Motivo de la revocación')
      .setRequired(true)
      .setStyle(TextInputStyle.Paragraph);

    modal.addComponents(new ActionRowBuilder().addComponents(motivo));
    await interaction.showModal(modal);
  }
};
