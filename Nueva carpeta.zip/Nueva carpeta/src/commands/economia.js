const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { get } = require('../database/db');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('economia')
    .setDescription('Consulta el saldo económico del ciudadano.'),

  async execute(interaction) {
    const citizen = get('SELECT * FROM citizens WHERE discord_id = ?', [interaction.user.id]);
    if (!citizen) {
      await interaction.reply({ content: config.messages.mustRegister, flags: 64 });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(config.colors.gov)
      .setTitle('Economía')
      .setDescription('Saldo: $0.00');

    await interaction.reply({ embeds: [embed] });
  }
};
