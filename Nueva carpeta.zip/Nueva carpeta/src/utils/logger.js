const logger = {
  info: (message) => console.log(`[INFO] ${message}`),
  warn: (message) => console.log(`[WARN] ${message}`),
  error: (message, error = '') => console.log(`[ERROR] ${message}`, error)
};

module.exports = logger;
