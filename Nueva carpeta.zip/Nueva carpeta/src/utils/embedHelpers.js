const { EmbedBuilder } = require('discord.js');
const config = require('../config.json');

const buildCitizenCard = (citizen) => new EmbedBuilder()
  .setColor(config.colors.gov)
  .setTitle('🇵🇦 REPÚBLICA DE PANAMÁ')
  .setDescription('Registro Civil')
  .addFields(
    { name: 'Nombre', value: citizen.full_name, inline: true },
    { name: 'Número de cédula virtual', value: citizen.cedula, inline: true },
    { name: 'Edad', value: String(citizen.age), inline: true },
    { name: 'Sexo', value: citizen.sex, inline: true },
    { name: 'Provincia', value: citizen.province, inline: true },
    { name: 'Distrito', value: citizen.district, inline: true },
    { name: 'Corregimiento', value: citizen.corregimiento, inline: true },
    { name: 'Fecha de registro', value: citizen.created_at, inline: false },
    { name: 'ID del ciudadano', value: citizen.internal_id, inline: false }
  )
  .setTimestamp();

module.exports = { buildCitizenCard };
