const config = require('../config.json');

const hasRole = (member, roleName) => {
  const roleValue = config.roles?.[roleName];
  const roleId = config.roleIds?.[roleName];

  if (!member?.roles?.cache) return false;

  return member.roles.cache.some((role) => {
    const matchesName = roleValue ? role.name?.toLowerCase?.() === roleValue.toLowerCase() : false;
    const matchesId = roleId ? role.id === roleId : false;
    return matchesName || matchesId;
  });
};

const requireRole = (interaction, roleName) => {
  if (!hasRole(interaction.member, roleName)) {
    interaction.reply({ content: config.messages.notAuthorized, flags: 64 });
    return false;
  }
  return true;
};

module.exports = { hasRole, requireRole };
