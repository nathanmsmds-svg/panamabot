# Interactions

Esta carpeta está reservada para handlers y extensiones de componentes interactivos del bot, como botones, select menus y modales complejos.
