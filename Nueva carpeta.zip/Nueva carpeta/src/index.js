const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Collection, Partials } = require('discord.js');
const defaultConfig = require('./config.json');
const config = {
  ...defaultConfig,
  token: process.env.DISCORD_TOKEN || defaultConfig.token,
  clientId: process.env.DISCORD_CLIENT_ID || defaultConfig.clientId,
  guildId: process.env.DISCORD_GUILD_ID || defaultConfig.guildId,
  database: { ...defaultConfig.database, path: process.env.DB_PATH || defaultConfig.database.path }
};
const { initDatabase } = require('./database/db');
const logger = require('./utils/logger');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel, Partials.Message, Partials.User]
});

client.commands = new Collection();
client.buttons = new Collection();
client.modals = new Collection();

const commandsDir = path.join(__dirname, 'commands');
const eventsDir = path.join(__dirname, 'events');

const loadCommands = () => {
  for (const file of fs.readdirSync(commandsDir).filter((f) => f.endsWith('.js'))) {
    const command = require(path.join(commandsDir, file));
    if (!command?.data?.name) continue;
    client.commands.set(command.data.name, command);
    logger.info(`Comando cargado: /${command.data.name}`);
  }
};

const loadEvents = () => {
  for (const file of fs.readdirSync(eventsDir).filter((f) => f.endsWith('.js'))) {
    const event = require(path.join(eventsDir, file));
    if (typeof event === 'function') {
      const name = file.replace(/\.js$/, '');
      logger.info(`Evento cargado: ${name}`);
      event(client);
    }
  }
};

(async () => {
  try {
    initDatabase();
    loadCommands();
    loadEvents();

    client.login(config.token).catch((error) => {
      logger.error('No se pudo iniciar el bot.', error);
      process.exit(1);
    });
  } catch (error) {
    logger.error('Error al iniciar el sistema.', error);
    process.exit(1);
  }
})();
