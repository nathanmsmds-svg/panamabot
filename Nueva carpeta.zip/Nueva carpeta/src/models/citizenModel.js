const { get, run } = require('../database/db');

const findCitizenByDiscordId = (discordId) => get('SELECT * FROM citizens WHERE discord_id = ?', [discordId]);
const findCitizenByCedula = (cedula) => get('SELECT * FROM citizens WHERE cedula = ?', [cedula]);

const createCitizenRecord = (payload) => {
  const createdAt = new Date().toISOString();
  run(
    `INSERT INTO citizens (internal_id, discord_id, full_name, cedula, birth_date, age, sex, province, district, corregimiento, address, nationality, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [payload.internalId, payload.discordId, payload.fullName, payload.cedula, payload.birthDate, payload.age, payload.sex, payload.province, payload.district, payload.corregimiento, payload.address, payload.nationality, createdAt, createdAt]
  );
};

module.exports = {
  findCitizenByDiscordId,
  findCitizenByCedula,
  createCitizenRecord
};
